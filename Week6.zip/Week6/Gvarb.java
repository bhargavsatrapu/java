package Week6;

public class Gvarb {
public static void main(String arg[]) {
	 GlobelVariables s=new GlobelVariables();
	 int y=s.a*s.b;
	 System.out.println(y);
	 
	 
}
public static int akil(int a,int b){
	 GlobelVariables s=new GlobelVariables();
	 return(s.a+s.b);
}
}
