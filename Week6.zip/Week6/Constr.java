package Week6;

public class Constr {
  float x,y,z;
  Constr(int a,float b)
  {
	  x=a;
	  y=b;
  }
  void akhi()
  {
	  System.out.println(x+y);
  }
}
