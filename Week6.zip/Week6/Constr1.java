package Week6;

public class Constr1 {
 public static void main (String args[])
 {
	 Constr d=new Constr(5,5.55f);
	 d.akhi();
 }
}
