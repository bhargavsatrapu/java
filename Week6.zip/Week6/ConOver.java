package Week6;

public class ConOver {
	static void orange() {
		int a = 5;
		int b = 8;
		int c = 6;
		System.out.println(a);
	}

	void apple() {
		int d = 7;
		int e = 9;
		int f = 3;
		System.out.println(d + e + f);
	}

	void mango() {
		int g = 5;
		int h = 7;
		int i = 8;
		System.out.println(g + h + i);

	}

	public  static void main(String arg[]) {
	//	ConOver g = new ConOver();
	//	g.orange();
		//g.apple();
	//	g.mango();
		//System.out.println(g.x + g.y + g.z);
		ConOver c=new ConOver();
	      c.orange();
		
	}
}