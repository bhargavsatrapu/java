package Week6;

public class GlobelVariables {
	int a = 50;
	int b = 45;

	public static void main(String arg[]) {

		GlobelVariables s = new GlobelVariables();
		int z = s.a + s.b;
		System.out.println(z);
		int b=anr(20,30);
		System.out.println(b);
	}

	public static int anr(int x, int y) {
		return (x * y);
	}
}
