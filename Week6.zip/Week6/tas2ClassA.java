package Week6;

public class tas2ClassA {
 protected static void mai()
 {
	 System.out.println("Hello woprld");
 }
}
