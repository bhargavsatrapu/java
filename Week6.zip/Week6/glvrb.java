package Week6;

public class glvrb 
{
	 static int gv=0;
	 public static void main(String args[]) 
	 {
	 	ak1(50,20);	 
	 	ak2(82,40);
	 	int z=ak3(20,40);
	 	System.out.println(z);
	 }
	 
	 public static void ak1(int x,int y) 
	 {
		int  a=x;
		int  b=y;
		int	z=a+b;
		
		int f=z*gv;
		System.out.println(z);
		System.out.println(f);
	 }
	 
	 public static void ak2(int x,int y) {
		 int a=x;
		 int b=y;
		 System.out.println(a*b);
	 }
	 
	 public static int ak3(int x,int y)
	 {
		 int p=(x+y)-(x-y);
		 return p;
	 }
 

}
