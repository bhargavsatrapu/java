package Week6;

public class Global {
  static   int x = 10;
	static int y = 25;

	static void orange() {
		int a = 5;
		int b = 8;
		int c = 6;
		System.out.println(a + b + c);
	}

	void apple() {
		int d = 7;
		int e = 9;
		int f = 3;
		System.out.println(d + e + f);
	}

	static void mango() {
		int g = 5;
		int h = 7;
		int i = 8;
		System.out.println(g + h + i+x);

	}

	public static void main(String arg[]) {
  //Global g=new Global();

		//g.mango();
		mango();
	}
}
