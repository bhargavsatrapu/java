package Week6;

public class parent1 {
	public static void main() {
		System.out.println("trump");
	}

	public static void bc2(String x, int y) {
		System.out.println("obama");
	}
}

class child extends parent1 {

	public static void main(String args[]) {
	  System.out.println("modi");
		

	}
}
class mom  {
	public static void main (String arg[]) {
		child c=new child();
		c.main();
				
	}
}
