package Week6;

public class retun {
	static String p="Akhil";
	static float f=1.2455f;
  
  public static void main(String arg[])
  {	  
	  int c=abbx(50,40);
	  System.out.println(c);
	  double d=abbx2(1.01,2.22);
	  System.out.println(d);
	  String s=abbx3("Akhil","Chandra");
	  System.out.println(s);
	  float f=abbx4(1.0225f,20.3245f);
	  System.out.println(f);
  }
  
  static int abbx(int x,int y) 
  {
	  return(x+y);	  
  }
  
  public static double abbx2(double x,double y)
  {
	  return x+y;
  }
  
  public static String abbx3(String x,String y)
  {
	  String p=x+y;
	  return p;
  }
  public static float abbx4(float x,float y)
  {
	  return x+y;
  }
}
