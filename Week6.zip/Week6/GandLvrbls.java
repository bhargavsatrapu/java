package Week6;

public class GandLvrbls {
	int x = 5;
	int y = 10;
	int z = 6;

	void orange() {
		int a = 5;
		int b = 8;
		int c = 7;
		System.out.println(a + b + c);
	}

	void apple() {
		int d = 7;
		int e = 9;
		int f = 3;
		System.out.println(d + e + f);
	}

	void mango() {
		int g = 5;
		int h = 7;
		int i = 8;
		System.out.println(g + h + i);

	}

	public static void main(String arg[]) {
		GandLvrbls g = new GandLvrbls();
		g.orange();
		g.apple();
		g.mango();
		System.out.println(g.x + g.y + g.z);
	}
}
