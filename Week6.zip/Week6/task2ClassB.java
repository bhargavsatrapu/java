package Week6;

public class task2ClassB {
	public static void main(String args[]) 
	 {
		tas2ClassA b=new tas2ClassA();
		   b.mai();
	 }
}
