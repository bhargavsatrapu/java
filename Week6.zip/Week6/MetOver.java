package Week6;

public class MetOver {
	public static void main(String args[])
	{
		ak1(20,30);
		ak1("Akhil",365);
		String b=ak1("Akhil","Rock");
    	System.out.println(b);
    	double f=ak1(10.2444f,5.00d);
    	System.out.println(f);
	}
    public static void ak1(int x,int y)
    {
    	int m=x*y;
    	int n=x-y;
    	System.out.println(m-n);
    	
    }
    public static void ak1(String x,int y)
    {
    System.out.println(x+y);
    }
    public static String ak1(String x,String y)
    {
    	return x+y;
    }
    public static double ak1(float x,double y)
    {
    	return x+y;
    }
}

