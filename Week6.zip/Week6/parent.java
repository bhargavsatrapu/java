package Week6;

class mother {
	public static void bc1() {
		System.out.println("trump");
	}

	public static void bc2(String x, int y) {
		System.out.println("obama");
	}
}

class child extends mother {

	public static void bc3(String args[]) {
		System.out.println("hao");

	}
}

public class parent {
	public static void main(String args[]) {
      child c=new child();
      c.bc1();
	}
}
