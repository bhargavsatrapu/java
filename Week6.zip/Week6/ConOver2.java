package Week6;

public class ConOver2 {
	public static void main(String args)
	{
		System.out.println("hello world");
	}
	public void akhil()
	{
		ConOver c=new ConOver();
		c.orange();
		
	}
}
